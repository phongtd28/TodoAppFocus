export const screenDialogs = {
    Register: 'Register',
    ForgotPass: ' ForgotPass',
    Login: 'Login',
    Confirn: 'Confirm',
    None: 'None'
}
