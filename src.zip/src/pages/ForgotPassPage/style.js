import styled from 'styled-components'

export const ForgotPassPageStyled = styled.div`
    .gr-btn {
        display: flex;
        justify-content: flex-end;
        gap: 10px;
    }
`
