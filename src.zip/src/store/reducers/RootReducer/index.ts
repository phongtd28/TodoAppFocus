import { combineReducers } from 'redux'
import homepageReducer from '../HomepageReducer'

const rootReducer = combineReducers({
    homepageReducer
})
export default rootReducer
