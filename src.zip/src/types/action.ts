export type IAuthenPayloadAction = {
    username: string
    password: string
    keepMeIn: boolean
}
